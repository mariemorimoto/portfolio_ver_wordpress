<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>sample</title>
</head>
 
<body>
 
<h2>問合せ内容</h2>    
 
<form action="./finish.php" method="post">
 
<table>
<tr>
<td>Name</td>
<td><?php echo $_POST["name"]; ?></td>
</tr>
<tr>
<td>Adress</td>
<td><?php echo $_POST["email"]; ?></td>
</tr>
<tr>
<td>message</td>
<td><?php echo $_POST["message"]; ?></td>
</tr>
</table>

<input type="hidden" value="<?php echo $_POST['name']; ?>" name="name"/>
<input type="hidden" value="<?php echo $_POST['email']; ?>" name="email"/>
<input type="hidden" value="<?php echo $_POST['message']; ?>" name="message"/>
 
<input type="submit" value="送信" />
</form>
 
</body>
    
</html>